import ContactContent from "./ContactContent";

export const metadata = {
  title: "Contact Trail Logic Studio",
};

export default function ContactPage() {
  return <ContactContent />;
}
